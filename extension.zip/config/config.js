// config.example.js
const CONFIG = {
    OPENAI_API_KEY: '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'
  };