// This can remain empty for now
// You can add Gmail-specific listeners here if needed later