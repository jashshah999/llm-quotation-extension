// config.js
const CONFIG = {
    OPENAI_API_KEY: ''  // API key will be set through extension settings
};